﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tarea1_C14644_IF4101.Models;
using Tarea1_IF4101_C14644.Models;

namespace Tarea1_C14644_IF4101.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HorarioController : ControllerBase
    {
        private readonly DbDataContext _dbDataContext;

        public HorarioController(DbDataContext dbDataContext)
        {
            _dbDataContext = dbDataContext;
        }

        // GET: api/Horario
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Horario>>> GetHorarios()
        {
            return await _dbDataContext.Horarios.ToListAsync();
        }

        // GET: api/Horario/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Horario>> GetHorario(int id)
        {
            var horario = await _dbDataContext.Horarios.FindAsync(id);

            if (horario == null)
            {
                return NotFound();
            }

            return horario;
        }

        // POST: api/Horario
        [HttpPost]
        public async Task<ActionResult<Horario>> PostHorario(Horario horario)
        {
            _dbDataContext.Horarios.Add(horario);
            await _dbDataContext.SaveChangesAsync();

            return CreatedAtAction("GetHorario", new { id = horario.IdHorario }, horario);
        }   
        private bool HorarioExists(int id)
        {
            return _dbDataContext.Horarios.Any(e => e.IdHorario == id);
        }
    }
}
