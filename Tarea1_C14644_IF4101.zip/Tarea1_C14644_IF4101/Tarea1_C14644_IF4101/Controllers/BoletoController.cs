﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tarea1_IF4101_C14644.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tarea1_C14644_IF4101.Models;

namespace Tarea1_IF4101_C14644.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BoletoController : ControllerBase
    {
        private readonly DbDataContext _dbDataContext;

        public BoletoController(DbDataContext dbDataContext)
        {
            _dbDataContext = dbDataContext;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Boleto>> GetBoleto(int id)
        {
            var boleto = await _dbDataContext.Boletos.FindAsync(id);
            if (boleto == null)
            {
                return NotFound();
            }
            return boleto;
        }

        [HttpPost]
        public async Task<ActionResult<Boleto>> PostBoleto(Boleto boleto)
        {
            _dbDataContext.Boletos.Add(boleto);
            await _dbDataContext.SaveChangesAsync();
            return CreatedAtAction(nameof(GetBoleto), new { id = boleto.IdBoleto }, boleto);
        }
        private bool BoletoExists(int id)
        {
            return _dbDataContext.Boletos.Any(e => e.IdBoleto == id);
        }
    }
}
