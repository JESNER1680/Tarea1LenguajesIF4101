﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tarea1_C14644_IF4101.Models;
using Tarea1_IF4101_C14644.Models;

namespace Tarea1_C14644_IF4101.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParadaRutaController : ControllerBase
    {
        private readonly DbDataContext _dbDataContext;

        public ParadaRutaController(DbDataContext dbDataContext)
        {
            _dbDataContext = dbDataContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ParadaRuta>>> GetParadasRutas()
        {
            var paradasRutas = await _dbDataContext.ParadaRutas.ToListAsync();
            if (paradasRutas == null || paradasRutas.Count == 0)
            {
                return NotFound();
            }

            return paradasRutas;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ParadaRuta>> GetParadaRuta(int id)
        {
            var paradaRuta = await _dbDataContext.ParadaRutas.FindAsync(id);
            if (paradaRuta == null)
            {
                return NotFound();
            }

            return paradaRuta;
        }

        [HttpPost]
        public async Task<ActionResult<ParadaRuta>> PostParadaRuta(ParadaRuta paradaRuta)
        {
            _dbDataContext.ParadaRutas.Add(paradaRuta);
            await _dbDataContext.SaveChangesAsync();
            return CreatedAtAction(nameof(GetParadaRuta), new { id = paradaRuta.Id }, paradaRuta);
        }
        private bool ParadaRutaExists(int id)
        {
            return _dbDataContext.ParadaRutas.Any(e => e.Id == id);
        }
    }
}
