﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tarea1_C14644_IF4101.Models;
using Tarea1_IF4101_C14644.Models;

namespace Tarea1_C14644_IF4101.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParadaController : ControllerBase
    {
        private readonly DbDataContext _dbDataContext;

        public ParadaController(DbDataContext dbDataContext)
        {
            _dbDataContext = dbDataContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Parada>>> GetParadas()
        {
            var paradas = await _dbDataContext.Paradas.ToListAsync();
            if (paradas == null || paradas.Count == 0)
            {
                return NotFound();
            }

            return paradas;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Parada>> GetParada(int id)
        {
            var parada = await _dbDataContext.Paradas.FindAsync(id);
            if (parada == null)
            {
                return NotFound();
            }

            return parada;
        }

        [HttpPost]
        public async Task<ActionResult<Parada>> PostParada(Parada parada)
        {
            _dbDataContext.Paradas.Add(parada);
            await _dbDataContext.SaveChangesAsync();
            return CreatedAtAction(nameof(GetParada), new { id = parada.IdParada }, parada);
        }
        private bool ParadaExists(int id)
        {
            return _dbDataContext.Paradas.Any(e => e.IdParada == id);
        }
    }
}
