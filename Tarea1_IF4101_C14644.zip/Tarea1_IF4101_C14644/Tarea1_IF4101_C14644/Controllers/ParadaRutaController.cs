﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tarea1_IF4101_C14644.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea1_IF4101_C14644.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParadaRutaController : ControllerBase
    {
        private readonly ParadaRutaContext _paradaRutaContext;

        public ParadaRutaController(ParadaRutaContext paradaRutaContext)
        {
            _paradaRutaContext = paradaRutaContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ParadaRuta>>> GetParadaRutas()
        {
            var paradaRutas = await _paradaRutaContext.paradaRutas.ToListAsync();
            if (paradaRutas == null || paradaRutas.Count == 0)
            {
                return NotFound();
            }
            return paradaRutas;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ParadaRuta>> GetParadaRuta(int id)
        {
            var paradaRuta = await _paradaRutaContext.paradaRutas.FindAsync(id);
            if (paradaRuta == null)
            {
                return NotFound();
            }
            return paradaRuta;
        }

        [HttpPost]
        public async Task<ActionResult<ParadaRuta>> PostParadaRuta(ParadaRuta paradaRuta)
        {
            _paradaRutaContext.paradaRutas.Add(paradaRuta);
            await _paradaRutaContext.SaveChangesAsync();
            return CreatedAtAction(nameof(GetParadaRuta), new { id = paradaRuta.Id }, paradaRuta);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutParadaRuta(int id, ParadaRuta paradaRuta)
        {
            if (id != paradaRuta.Id)
            {
                return BadRequest();
            }

            _paradaRutaContext.Entry(paradaRuta).State = EntityState.Modified;

            try
            {
                await _paradaRutaContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ParadaRutaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw; // Lanza la excepción para que se maneje a un nivel superior
                }
            }

            return NoContent();
        }

        private bool ParadaRutaExists(int id)
        {
            return _paradaRutaContext.paradaRutas.Any(e => e.Id == id);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteParadaRuta(int id)
        {
            var paradaRuta = await _paradaRutaContext.paradaRutas.FindAsync(id);
            if (paradaRuta == null)
            {
                return NotFound();
            }

            _paradaRutaContext.paradaRutas.Remove(paradaRuta);
            await _paradaRutaContext.SaveChangesAsync();
            return Ok();
        }
    }
}
