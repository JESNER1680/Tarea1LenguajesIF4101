﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tarea1_IF4101_C14644.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea1_IF4101_C14644.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParadaController : ControllerBase
    {
        private readonly ParadaContext _paradaContext;

        public ParadaController(ParadaContext paradaContext)
        {
            _paradaContext = paradaContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Parada>>> GetParadas()
        {
            var paradas = await _paradaContext.paradas.ToListAsync();
            if (paradas == null || paradas.Count == 0)
            {
                return NotFound();
            }
            return paradas;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Parada>> GetParada(int id)
        {
            var parada = await _paradaContext.paradas.FindAsync(id);
            if (parada == null)
            {
                return NotFound();
            }
            return parada;
        }

        [HttpPost]
        public async Task<ActionResult<Parada>> PostParada(Parada parada)
        {
            _paradaContext.paradas.Add(parada);
            await _paradaContext.SaveChangesAsync();
            return CreatedAtAction(nameof(GetParada), new { id = parada.IdParada }, parada);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutParada(int id, Parada parada)
        {
            if (id != parada.IdParada)
            {
                return BadRequest();
            }

            _paradaContext.Entry(parada).State = EntityState.Modified;

            try
            {
                await _paradaContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ParadaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw; // Lanza la excepción para que se maneje a un nivel superior
                }
            }

            return NoContent();
        }

        private bool ParadaExists(int id)
        {
            return _paradaContext.paradas.Any(e => e.IdParada == id);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteParada(int id)
        {
            var parada = await _paradaContext.paradas.FindAsync(id);
            if (parada == null)
            {
                return NotFound();
            }

            _paradaContext.paradas.Remove(parada);
            await _paradaContext.SaveChangesAsync();
            return Ok();
        }
    }
}
