﻿namespace Tarea1_IF4101_C14644.Models
{
    public class ParadaRuta
    {
        public int Id { get; set; }
        public int IdRuta { get; set; }
        public int IdParada { get; set; }
        public bool origen { get; set; }
        public bool destino { get; set; }
    }
}
