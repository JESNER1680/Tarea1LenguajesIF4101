﻿namespace Tarea1_IF4101_C14644.Models
{
    public class Asiento
    {
        public int IdAsiento { get; set; }
        public int NumeroAsiento { get; set; }
        public bool DisponibilidadAsiento { get; set; }
        public bool EstadoAsiento { get; set; }
    }
}
