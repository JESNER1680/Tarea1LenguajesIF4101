﻿using Microsoft.EntityFrameworkCore;

namespace Tarea1_IF4101_C14644.Models
{
    public class ParadaContext: DbContext
    {
        public ParadaContext(DbContextOptions<ParadaContext> options) : base(options)
        {

        }
        public DbSet<Parada> paradas { get; set; }
    }
}
