﻿using Microsoft.EntityFrameworkCore;

namespace Tarea1_IF4101_C14644.Models
{
    public class UsuarioAsientoContext: DbContext
    {
        public UsuarioAsientoContext(DbContextOptions<UsuarioAsientoContext> options) : base(options)
        {

        }
        public DbSet<UsuarioAsientoContext> usuarioAsientos { get; set; }
    }
}
