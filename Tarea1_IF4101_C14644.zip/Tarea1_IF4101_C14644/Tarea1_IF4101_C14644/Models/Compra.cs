﻿namespace Tarea1_IF4101_C14644.Models
{
    public class Compra
    {
        public int Id { get; set; }
        public int IdUsuario { get; set; }
        public int IdBoleto { get; set; }
    }
}
