﻿using Microsoft.EntityFrameworkCore;

namespace Tarea1_IF4101_C14644.Models
{
    public class ParadaRutaContext: DbContext
    {
        public ParadaRutaContext(DbContextOptions<ParadaRutaContext> options) : base(options)
        {

        }
        public DbSet<ParadaRuta> paradaRutas { get; set; }
    }
}
