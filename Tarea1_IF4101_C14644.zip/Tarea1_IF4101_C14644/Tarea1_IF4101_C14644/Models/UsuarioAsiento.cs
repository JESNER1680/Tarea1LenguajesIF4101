﻿namespace Tarea1_IF4101_C14644.Models
{
    public class UsuarioAsiento
    {
        public int IdAsiento { get; set; }
        public int IdUsuario {  get; set; } 
    }
}
