﻿namespace Tarea1_IF4101_C14644.Models
{
    public class Horario
    {
        public int IdHorario { get; set; }
        public string? HorarioText { get; set; }
        public int IdRuta { get; set; }
    }
}
